import threading
import numpy as np
from qpython import qconnection as qp
# import qpython.qconnection as qp
import queue


class K:

    def __init__(self, host, port, auth):
        self.queue = queue.Queue()
        self.host = host
        self.port = port
        self.auth = auth

    def isStop(self):
        self._stop = threading.Event()

    def connect(self):
        # 连接到KDB服务器
        self.q = qp.QConnection(self.host, self.port,self.auth )

    def open(self):
        # 打开链接
        self.q.open()

    def subscribe(self, table, sym):
        # 订阅A表更新
        self.q.sendAsync('.u.sub', np.string_(table), np.string_(sym))

    def receive(self):
        """ msg:
        [b'upd', b'request', rec.array([(b'test1', b'cddeceef-9ee9-3847-9172-3e3d7ab39b26', b'test', 8820.627192, 0, b'601818', 3., 200, 0., 0, 0, 0, b'', -1, b''),
           (b'test1', b'97911f28-7bfa-7efa-6c10-4fb48ceeb4f1', b'test', 8820.627192, 0, b'601818', 3., 200, 0., 0, 0, 0, b'', -1, b'')],
          dtype=[('sym', 'S5'), ('qid', 'S36'), ('accountname', 'S4'), ('time', '<f8'), ('entrustno', '<i4'), ('stockcode', 'S6'), ('askprice', '<f8'), ('askvol', '<i4'), ('bidprice', '<f8'), ('bidvol', '<i4'), ('withdraw', '<i4'), ('status', '<i4'), ('note', 'S1'), ('reqtype', '<i4'), ('params', 'S1')])]
        """
        while self._stop:
            # 接收数据
            msg = self.q.receive(data_only=True)
            # 将数据放入队列
            self.queue.put(msg)

    def close(self):
        self.q.close()

    def getQueue(self):
        return self.queue

if __name__ == '__main__':
    K('58.216.145.86',40000,"test:pass")